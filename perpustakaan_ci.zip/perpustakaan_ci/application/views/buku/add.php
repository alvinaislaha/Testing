<section class="content">
	<div class="row">
	<div class="col-sm-12">
	<div class="box box-danger">
		<div class="box-header">
			<h3 class="box-tittle">Tambah Buku</h3>
		</div>
		<div class="box-body">
			<form action="<?=site_url('buku/create');?>">
				<div class="box-body">
					<div class="form-group">
						<label>Judul Buku</label>
						<input type="text" name="judul_buku" class="form-control" value="" placeholder="Masukkan Judul Buku" required="required"></input>
					</div>
					<div class="form-group">
						<label>Kategori</label>
						<select from="id_kategori" size="1" min="0">
							<option value="1">Fiksi</option>
							<option value="2">Ilmiyah</option>
							<option value="3">Novel</option>
							<option value="4">Komik</option>
							<option value="5">Lainnya</option>
						</select>
					</div>
					<div class="form-group">
						<label>Pengarang</label>
						<input type="text" name="pengarang" class="form-control" value="" placeholder="Masukkan Nama Pengarang" required="required"></input>
					</div>
					<div class="form-group">
						<label>Tahun Terbit</label>
						<input type="number" name="tahun_terbit" class="form-control" min="0"></input>
					</div>
					<div class="form-group">
						<label for="exampleInputtext1">Penerbit</label>
						<input type="text" name="penerbit" class="form-control" id="exampleInputtext1" value="" placeholder="Penerbit" required="required"></input>
					</div>
					<div class="form-group">
						<label>ISBN</label>
						<input type="text" name="isbn" class="form-control" id="exampleInputtext1" value="" placeholder="ISBN" required="required"></input>
					</div>
					<div class="form-group">
						<label>Jumlah</label>
						<input type="number" name="jumlah" class="form-control" value="" placeholder="0" required="required" min="0"></input>
					</div>
					<div class="form-group">
						<label>Lokasi</label>
						<select from="lokasi" size="1" min="0">
							<option value="1">Rak 1</option>
							<option value="2">Rak 2</option>
							<option value="3">Rak 3</option>
							<option value="4">Rak 4</option>
							<option value="5">Rak 5</option>
						</select>
					</div>
				</div>
				<div class="box-footer">
					<button type="button" class="btn btn-default"><i class="fa fa-arrow-circle-left"></i>Batal</button>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-send"></i>Batal</button>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
</section>